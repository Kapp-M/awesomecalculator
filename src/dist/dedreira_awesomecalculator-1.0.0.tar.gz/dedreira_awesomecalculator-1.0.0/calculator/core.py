class Calculator:
    def __init__(self):
        pass

    def Add(self, value1, value2):
        return value1 + value2

    def Substract(self, value1, value2):
        return value1 - value2

    def Multiply(self, value1, value2):
        return value1 * value2

    def Divide(self, value1, value2):
        return value1 / value2